package model;

@SuppressWarnings("serial")
public class InvalidStatusToSwitchException extends Exception {
	public InvalidStatusToSwitchException (String s) {
		super(s);
	}
}
