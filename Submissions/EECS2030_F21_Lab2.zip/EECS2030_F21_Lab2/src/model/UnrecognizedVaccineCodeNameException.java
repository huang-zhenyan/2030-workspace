package model;


@SuppressWarnings("serial")
public class UnrecognizedVaccineCodeNameException extends Exception {
	public UnrecognizedVaccineCodeNameException(String s) {
		super(s);
	}
}
