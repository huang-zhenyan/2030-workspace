package model;

@SuppressWarnings("serial")
public class IllegalOperationException extends Exception {
	public IllegalOperationException(String s) {
		super(s);
	}
}
